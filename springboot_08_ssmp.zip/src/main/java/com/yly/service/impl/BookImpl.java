package com.yly.service.impl;/*
@author YLY
@create 2022-01-27-21:20
*/

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yly.dao.BookDao;
import com.yly.domain.Book;
import com.yly.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class BookImpl implements BookService {
@Autowired
    BookDao bookDao;
    @Override
    public Boolean update(Book book) {
        return bookDao.updateById(book) > 0;
    }

    @Override
    public Boolean delete(Integer id) {
        return bookDao.deleteById(id) > 0;
    }

    @Override//影响行数>0为真=0为假
    public Boolean save(Book book) {
        return bookDao.insert(book) > 0;
    }

    @Override
    public List<Book> GetAll() {
        return bookDao.selectList(null);
    }

    @Override
    public Book GetById(Integer id) {
        return bookDao.selectById(id);
    }


    @Override
    public IPage<Book> getPage(int currentPage, int pageSize) {
        Page page = new Page(currentPage, pageSize);
        return bookDao.selectPage(page,null);
    }

}
