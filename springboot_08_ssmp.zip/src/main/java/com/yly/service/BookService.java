package com.yly.service;/*
@author YLY
@create 2022-01-27-21:17
*/

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.sun.org.apache.xpath.internal.operations.Bool;
import com.yly.domain.Book;
import org.springframework.stereotype.Service;

import java.util.List;

public interface BookService {
    Boolean update(Book book);
    Boolean  delete(Integer id);
    Boolean save(Book book);
    List<Book> GetAll();
    Book GetById(Integer id);
    IPage<Book> getPage(int currentPage,int pageSize);
}
