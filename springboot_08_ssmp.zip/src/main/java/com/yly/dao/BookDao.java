package com.yly.dao;/*
@author YLY
@create 2022-01-27-20:33
*/

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yly.domain.Book;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface BookDao extends BaseMapper<Book> {

}
