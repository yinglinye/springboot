package com.yly.service;/*
@author YLY
@create 2022-01-27-21:26
*/

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.yly.domain.Book;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class BookServiceTestCase {
    @Autowired
    BookService bookService;

    @Test
    void testGetById(){
        System.out.println(bookService.GetById(1));
    }

    @Test
    void testSave(){
        Book book = new Book();
        book.setDescription("测试数据2");
        book.setName("3");
        book.setType("3");
        bookService.save(book);


    }
    @Test
    void testDel(){
        bookService.delete(6);


    }
    @Test
    void testUpdate(){
        Book book = new Book();
        book.setType("修改测试");
        book.setName("修改测试1");
        book.setDescription("修改测试1");
        book.setId(5);
        bookService.update(book);

    }
    @Test
    void testSelectAll(){
        System.out.println(bookService.GetAll());
    }
    @Test
    void testGetPage(){
//        获取第几页数据，一页多少数据
        IPage<Book> page = bookService.getPage(2, 2);
        System.out.println(page.getRecords());
        System.out.println(page.getCurrent());
        System.out.println(page.getSize());
        System.out.println(page.getTotal());
    }


}
