package com.yly.controller.utils;/*
@author YLY
@create 2022-01-27-22:36
*/

//用于统一数据格式
public class R{
    private Object data;
    private boolean flag;
    private String msg;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    @Override
    public String toString() {
        return "R{" +
                "data=" + data +
                ", flag=" + flag +
                ", msg='" + msg + '\'' +
                '}';
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public R(Boolean flag){
        this.flag=flag;
    }
    public R(){}
    public R(Boolean flag,Object data){
        this.flag=flag;
        this.data=data;
    }

    public R(boolean flag, String msg) {
        this.flag = flag;
        this.msg = msg;
    }
    public R(String msg) {
        this.flag = false;
        this.msg = msg;
    }
}
