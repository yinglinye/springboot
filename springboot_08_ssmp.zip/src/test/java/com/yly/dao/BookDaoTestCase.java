package com.yly.dao;/*
@author YLY
@create 2022-01-27-20:37
*/

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yly.domain.Book;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.swing.*;

@SpringBootTest

public class BookDaoTestCase {
    @Autowired
    private BookDao bookDao;
    @Test
    void testGetById(){
        System.out.println(bookDao.selectById(1));
    }

    @Test
    void testSave(){
        Book book = new Book();
        book.setDescription("测试数据2");
        book.setName("3");
        book.setType("3");
        bookDao.insert(book);


    }
    @Test
    void testDel(){
        bookDao.deleteById(4);


    }
    @Test
    void testUpdate(){
        Book book = new Book();
        book.setType("修改测试");
        book.setName("修改测试1");
        book.setDescription("修改测试1");
        book.setId(4);
        bookDao.updateById(book);

    }
    @Test
    void testSelectAll(){
        System.out.println(bookDao.selectList(null));
    }
    @Test
    void testGetPage(){
//        获取第几页数据，一页多少数据
        IPage page= new Page(2,2);
        bookDao.selectPage(page,null);
        System.out.println(page.getRecords());
        System.out.println(page.getCurrent());
        System.out.println(page.getSize());
        System.out.println(page.getTotal());
    }
    @Test
    void testGetBy(){
        QueryWrapper<Book> qw = new QueryWrapper<>();
        qw.like("name","应");
        bookDao.selectList(qw);
    }
    @Test
    void testGetBy2(){
        String name=null;
        LambdaQueryWrapper<Book> lqw = new LambdaQueryWrapper<>();
        lqw.like(name!=null,Book::getName,name);
        bookDao.selectList(lqw);

    }

}
